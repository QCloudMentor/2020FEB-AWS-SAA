# Redirect-to-URLShortenerWebsite
# Environment Variables: URLShortenerWebsite = https://xxx.cloudfront.net/

import json
import os

def lambda_handler(event, context):
    # TODO implement
     env_URLShortenerWebsite = os.environ['URLShortenerWebsite']
     
     
     return {
        'statusCode': 301,
        'body': '',
        'headers' : {
                 'Location': env_URLShortenerWebsite
         }
     }
